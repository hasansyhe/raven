# import libraries
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from raventabswidget import *
import os
import sys

class gui_raven(QWidget):
	def __init__(self):
		super().__init__()
		# create path
		self.path_home = os.getcwd()
		# set window title
		self.setWindowTitle("Raven Virtual Lab - Developer Tools")
		# set window icon
		self.setWindowIcon(QIcon(f"{self.path_home}/png/icon.png"))
		
		# mianlayout
		self.mianlayout = QVBoxLayout()
		self.setLayout(self.mianlayout)

		body_layout = QHBoxLayout()
		self.mianlayout.addLayout(body_layout)
		# function
		self.body_program(body_layout)
		self.statusbar_program(self.mianlayout)

	def body_program(self, layout):
		# left layout
		leftlayout = QVBoxLayout()
		# right layout
		rightlayout = QVBoxLayout()
		# add
		layout.addLayout(leftlayout)
		layout.addLayout(rightlayout)

		# notebook

		self.notebook = QTabWidget()

		# tabs
		home_tab = home_Widget(log=self.log_widget)
		repair_tab = repair_Widget()
		backup_tab = backup_Widget()
		flash_tab = flash_Widget()
		help_tab = help_Widget()
		settings_tab = setting_Widget()
		# add tabs to noteboot
		self.notebook.addTab(home_tab, "Home")
		self.notebook.addTab(repair_tab, "Repair")
		self.notebook.addTab(backup_tab, "Backup")
		self.notebook.addTab(flash_tab, "Flash")
		self.notebook.addTab(help_tab, "Help Center")
		self.notebook.addTab(settings_tab, "Settings")
		leftlayout.addWidget(self.notebook)

		# function
		self.log_widget(rightlayout)

	def log_widget(self, layout):
		log_box = QGroupBox("Terminal Log - E")
		box_log_layout = QVBoxLayout()
		log_box.setLayout(box_log_layout)
		layout.addWidget(log_box)

		# log widget
		self.log_widget = QPlainTextEdit()
		self.log_widget.setStyleSheet("width:200px;")
		self.log_widget.setReadOnly(True)
		box_log_layout.addWidget(self.log_widget)

		# progressbar box
		self.progressbar_box = QGroupBox("Progress Line")
		layout_progressbar = QHBoxLayout()
		self.progressbar_box.setLayout(layout_progressbar)
		layout.addWidget(self.progressbar_box)
		# progressbar widget
		self.progressbar_widget = QProgressBar()
		layout_progressbar.addWidget(self.progressbar_widget)

	def statusbar_program(self, layout):
		statusbar_box = QGroupBox("Status Bar")
		layout_statusbar = QHBoxLayout()
		statusbar_box.setLayout(layout_statusbar)
		layout.addWidget(statusbar_box)

		path_label = QLabel(f"Raven Path : <font color='#008080'> {self.path_home}     </font>")
		version_label = QLabel(f"Raven Version : <font color='#008080'>1.17</font>")
		root_label = QLabel()
		empty_label_0 = QLabel()
		layout_statusbar.addWidget(path_label)
		layout_statusbar.addWidget(version_label)
		layout_statusbar.addWidget(root_label)
		layout_statusbar.addWidget(empty_label_0)

def main():
	path = os.getcwd()
	# dont edit this
	def_folder_pull = open(f"{path}/def_pull.mar", "r").read()
	if(def_folder_pull == ''):
		def_folder_pull = open(f"{path}/def_pull.mar", "w")
		def_folder_pull.write(f"{path}/p_files")
		def_folder_pull.close()
	# create raven program
	app = QApplication(sys.argv)
	raven = gui_raven()
	raven.show()
	app.setStyle("Fusion")
	sys.exit(app.exec_())
if __name__ == '__main__':
	main()