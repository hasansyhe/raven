from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import functions_raven
import os

class home_Widget(QWidget):
	def __init__(self, log):
		super().__init__()
		self.log_home = log
		# create key root
		self.path = os.getcwd()
		key = open(f"{self.path}/maryam.ke", "r")
		self.keyRoot = key.read()
		key.close()
		# push_dir
		folder_ = open(f"{self.path}/def_push.mar")
		self.push_dir = folder_.read()
		folder_.close()
		# pull_dir
		folder_pull = open(f"{self.path}/def_pull.mar")
		self.raven_pull_folder = folder_pull.read()
		folder_pull.close()

		# main layout
		main_layout = QVBoxLayout()
		self.setLayout(main_layout)

		# event box
		in_event_box = QGroupBox("Events and Input")
		layout_in_event = QVBoxLayout()
		in_event_box.setLayout(layout_in_event)
		main_layout.addWidget(in_event_box)
		# event
		layout_event = QHBoxLayout()
		# add this layout to layout_in_event
		layout_in_event.addLayout(layout_event)
		# combobox
		# list events
		events_list = ["KEYCODE_HOME", "KEYCODE_SOFT_LEFT","KEYCODE_BACK", "KEYCODE_CALL", "KEYCODE_ENDCALL",
		"KEYCODE_VOLUM_UP", "KEYCODE_VOLUM_DOWN", "KEYCODE_POWER", "KEYCODE_CAMERA", "KEYCODE_CLEAR",
		"KEYCODE_SPACE", "KEYCODE_ENTER", "KEYCODE_DEL", "KEYCODE_FOCUS", "KEYCODE_MENU",
		"KEYCODE_NOTIFICATON", "KEYCODE_MEDIA_PLAY_PAUSE", "KEYCODE_MEDIA_STOP", "KEYCODE_MEDIA_NEXT",
		"KEYCODE_MEDIA_PREVIOUS"]
		self.combobox_event = QComboBox()
		# configure combobox styling
		self.combobox_event.setStyleSheet("width:350px;")
		layout_event.addWidget(self.combobox_event)
		for event in events_list:
			self.combobox_event.addItem(event)
		# input
		layout_input = QHBoxLayout()
		# add this layout to layout_in_event
		layout_in_event.addLayout(layout_input)
		# add button
		send_event = QPushButton("send")
		send_event.clicked.connect(self.send_event_function)
		layout_event.addWidget(send_event)
		# text input
		self.text_input = QLineEdit()
		# set the text placeholder
		self.text_input.setPlaceholderText("Enter Your Text")
		layout_input.addWidget(self.text_input)
		# add button
		send_text = QPushButton("send")
		send_text.clicked.connect(self.send_text_event)
		layout_input.addWidget(send_text)

		# bridge box
		trans_box = QGroupBox("Files Transfer and Install Packages")
		layout_trans = QVBoxLayout()
		trans_box.setLayout(layout_trans)
		main_layout.addWidget(trans_box)

		# layouts
		push_layout = QHBoxLayout()
		pull_layout = QHBoxLayout()
		install_layout = QHBoxLayout()
		# add this layouts to layout_trans
		layout_trans.addLayout(push_layout)
		layout_trans.addLayout(pull_layout)
		layout_trans.addLayout(install_layout)
		# push files widgets
		self.push_file_path = QLineEdit()
		self.push_file_path.setPlaceholderText("Path of file")
		# add
		push_layout.addWidget(self.push_file_path)
		# create buuton and add
		self.push_button = QPushButton("Push")
		self.push_button.clicked.connect(self.push_dialog_function)
		push_layout.addWidget(self.push_button)
		# pull files widgets
		self.pull_file_path = QLineEdit()
		self.pull_file_path.setPlaceholderText("Path of file")
		# add
		pull_layout.addWidget(self.pull_file_path)
		# create pull button
		pull_button = QPushButton("Pull")
		pull_button.clicked.connect(self.pull_files_function)
		pull_layout.addWidget(pull_button)
		# install package
		self.install_path = QLineEdit()
		self.install_path.setPlaceholderText("Path of (APK) file")
		# add
		install_layout.addWidget(self.install_path)
		# button
		install_button = QPushButton("Install")
		install_button.clicked.connect(self.install_apk_function)
		install_layout.addWidget(install_button)

		# actions layout
		actions_layout = QHBoxLayout()
		main_layout.addLayout(actions_layout)

		# box_boot_buttons
		button_boot_box = QGroupBox("Boot")
		layout_boot_button = QVBoxLayout()
		button_boot_box.setLayout(layout_boot_button)
		actions_layout.addWidget(button_boot_box)
		# buttons
		reboot_but = QPushButton("Reboot")
		reboot_but.clicked.connect(self.reboot_function)
		reboot_but.setIcon(QIcon(f"{self.path}/png/56824.png"))
		poweroff_but = QPushButton("Shutdown")
		poweroff_but.clicked.connect(self.poweroff_function)
		poweroff_but.setIcon(QIcon(f"{self.path}/png/50050.png"))
		recovery_but = QPushButton("Recovery")
		recovery_but.clicked.connect(self.recovery_function)
		recovery_but.setIcon(QIcon(f"{self.path}/png/14521.png"))
		download_but = QPushButton("Download")
		download_but.clicked.connect(self.download_function)
		download_but.setIcon(QIcon(f"{self.path}/png/14089.png"))
		bootloader_but = QPushButton("Bootloader")
		bootloader_but.clicked.connect(self.bootloader_function)
		bootloader_but.setIcon(QIcon(f"{self.path}/png/50051.png"))
		get_info_but = QPushButton("Read Info - E")
		get_info_but.setIcon(QIcon(f"{self.path}/png/56936.png"))
		css_0 = """
		QPushButton {
		text-align:left;
		padding:5px 10px;
		}
		"""
		list_boot_button = [reboot_but, poweroff_but, recovery_but, download_but,
		bootloader_but, get_info_but]
		# add buttons using for loop
		for but_boot in list_boot_button:
			if(self.keyRoot == "maryam"):
				but_boot.setEnabled(True)
			else:
				but_boot.setEnabled(False)
			but_boot.setStyleSheet(css_0)
			layout_boot_button.addWidget(but_boot)
		# empty label inside layout_boot_button
		label_boot_empty = QLabel()
		layout_boot_button.addWidget(label_boot_empty)

		# box_functions_buttons
		buttons_functions_box = QGroupBox("Tools")
		layout_functions = QVBoxLayout()
		buttons_functions_box.setLayout(layout_functions)
		actions_layout.addWidget(buttons_functions_box)

		# buttons
		fun_one = QPushButton("screen record")
		fun_one.clicked.connect(self.screen_record)
		fun_one.setIcon(QIcon(f"{self.path}/png/56773.png"))
		fun_two = QPushButton("Screen Capture")
		fun_two.clicked.connect(self.screen_cap_function)
		fun_two.setIcon(QIcon(f"{self.path}/png/15656.png"))
		fun_three = QPushButton("system partitions - E")
		fun_three.setIcon(QIcon(f"{self.path}/png/14404.png"))
		fun_four = QPushButton("system services - E")
		fun_four.setIcon(QIcon(f"{self.path}/png/69035.png"))
		fun_five = QPushButton("function - E")
		css = """
		QPushButton {
		text-align:left;
		padding:5px 10px;
		}
		"""
		list_fun_but = [fun_one, fun_two, fun_three, fun_four, fun_five]
		for fun_but in list_fun_but:
			fun_but.setStyleSheet(css)
			layout_functions.addWidget(fun_but)

		# empty label
		empty_home_label = QLabel()
		layout_functions.addWidget(empty_home_label)

	# all other functions under here
	def send_event_function(self):
		# change cursor
		self.setCursor(Qt.BusyCursor)
		# get event
		event_value = self.combobox_event.currentText()
		os.system(f"adb shell input keyevent {event_value}")
		# change cursor
		self.setCursor(Qt.ArrowCursor)

	def send_text_event(self):
		# change cursor
		self.setCursor(Qt.BusyCursor)
		# get text
		text = self.text_input.text()
		# to clear text
		self.text_input.clear()
		os.system(f"adb shell input text {text}")
		self.setCursor(Qt.ArrowCursor)

	def push_dialog_function(self):
		self.get_file = QFileDialog.getOpenFileName(self, "select file", self.path)
		path_file = str(self.get_file[0])
		if(self.get_file[0] == ''):
			QMessageBox.about(self, "Info", "No File To Push")
		else:
			self.push_file_path.setPlaceholderText(self.get_file[0])
			self.setCursor(Qt.BusyCursor)
			os.system(f"adb push {path_file} {self.push_dir}")
			self.setCursor(Qt.ArrowCursor)

	def pull_files_function(self):
		pull_path_files = self.pull_file_path.text()
		os.system(f"adb pull {pull_path_files} {self.raven_pull_folder}")
		QMessageBox.about(self, "Complete", f"Your Files inside<br> {self.path}/p_files")
		self.pull_file_path.clear()

	def install_apk_function(self):
		self.get_file = QFileDialog.getOpenFileName(self, "select apk file", self.path, "*.apk")
		path_file = str(self.get_file[0])
		if(self.get_file[0] == ''):
			QMessageBox.about(self, "Info", "No File To install")
		else:
			self.setCursor(Qt.BusyCursor)
			os.system(f"adb install {path_file}")
			self.setCursor(Qt.ArrowCursor)
			QMessageBox.about(self, "Complete", "Install apk file done !")

	def reboot_function(self):
		os.system("adb shell reboot")

	def poweroff_function(self):
		os.system("adb shell reboot -p")

	def recovery_function(self):
		os.system("adb shell reboot recovery")

	def download_function(self):
		os.system("adb shell reboot download")

	def bootloader_function(self):
		os.system("adb shell reboot bootloader")

	def screen_cap_function(self):
			get_name = QInputDialog.getText(self,"Screen Capture", "Enter name of PNG file", QLineEdit.Normal, "meryem") 
			os.system(f"adb shell screencap -p /sdcard/{get_name[0]}.png")

	def screen_record(self):
			get_name_video = QInputDialog.getText(self,"Screen Record", "Enter name of mp4 file", QLineEdit.Normal, "meryem") 
			os.system(f"mate-terminal -e 'bash -c \"adb shell screenrecord /sdcard/{get_name_video[0]}.mp4\"'")



class repair_Widget(QWidget):
	def __init__(self):
		super().__init__()
		# main layout
		main_layout = QHBoxLayout()
		self.setLayout(main_layout)

class backup_Widget(QWidget):
	def __init__(self):
		super().__init__()
		# main layout
		main_layout = QHBoxLayout()
		self.setLayout(main_layout)

class flash_Widget(QWidget):
	def __init__(self):
		super().__init__()
		# main layout
		main_layout = QHBoxLayout()
		self.setLayout(main_layout)
		# qtoolbox widget
		# items label
		fastboot_widget = QWidget()
		root_widget = QWidget()
		flash_boxs = QToolBox()
		# add items
		flash_boxs.addItem(fastboot_widget, "Flash : Fastboot - E")
		flash_boxs.addItem(root_widget, "Flash : Samsung - E")
		main_layout.addWidget(flash_boxs)

		# create layout inside QWidget - fastboot
		fastboot_layout = QVBoxLayout()
		fastboot_widget.setLayout(fastboot_layout)

		# add hint for fastboot
		fasthit_box = QGroupBox("Fastboot - Hints")
		hints_layout = QVBoxLayout()
		fasthit_box.setLayout(hints_layout)
		fastboot_layout.addWidget(fasthit_box)
		# hints label
		hint_fastboot = '''
		<h3>Flash Software Using Fastboot</h3><br>
		You can use fastboot to flash firmware img files,<br> just remember you can use
		command line to do that or <br>if you want do that without using any<br> terminals
		use this tool.<br>
		read more about it in Help Center TAB.
		'''
		label_fasthint = QLabel(hint_fastboot)
		hints_layout.addWidget(label_fasthint)

		# img files layout
		img_layout = QVBoxLayout()
		fastboot_layout.addLayout(img_layout)

		# brand layout
		brandbox = QGroupBox("Select Device Brand")
		brand_layout = QHBoxLayout()
		brandbox.setLayout(brand_layout)
		img_layout.addWidget(brandbox)
		# widgets brand
		brand_combobox = QComboBox()
		brand_combobox.addItem("--Select Brand--")
		brand_layout.addWidget(brand_combobox)
		# model
		model_combobox = QComboBox()
		model_combobox.addItem("--Select model--")
		brand_layout.addWidget(model_combobox)
		# select button
		select_button = QPushButton("Select Device")
		brand_layout.addWidget(select_button)

		boot_img_layout = QHBoxLayout()
		system_img_layout = QHBoxLayout()
		modem_img_layout = QHBoxLayout()
		recovery_img_layout = QHBoxLayout()
		actions_flash = QHBoxLayout()
		# add this layout to img_layout
		img_layout.addLayout(boot_img_layout)
		img_layout.addLayout(system_img_layout)
		img_layout.addLayout(modem_img_layout)
		img_layout.addLayout(recovery_img_layout)
		img_layout.addLayout(actions_flash)

		# WIDGETS FLASH
		boot_img = QLineEdit()
		boot_img.setReadOnly(True)
		boot_img.setPlaceholderText("Boot img file")
		system_img = QLineEdit()
		system_img.setReadOnly(True)
		system_img.setPlaceholderText("System img file")
		modem_img = QLineEdit()
		modem_img.setReadOnly(True)
		modem_img.setPlaceholderText("Modem img file")
		recovery_img = QLineEdit()
		recovery_img.setReadOnly(True)
		recovery_img.setPlaceholderText("Recovery img file")
		# buttons
		get_boot = QPushButton("Get")
		get_system = QPushButton("Get")
		get_modem = QPushButton("Get")
		get_recovery = QPushButton("Get")

		# add widgets to layouts
		boot_img_layout.addWidget(boot_img)
		boot_img_layout.addWidget(get_boot)
		system_img_layout.addWidget(system_img)
		system_img_layout.addWidget(get_system)
		modem_img_layout.addWidget(modem_img)
		modem_img_layout.addWidget(get_modem)
		recovery_img_layout.addWidget(recovery_img)
		recovery_img_layout.addWidget(get_recovery)

		# actions box
		actions_flash_box = QGroupBox("Flash Actions")
		actions_flash_layout = QHBoxLayout()
		actions_flash_box.setLayout(actions_flash_layout)
		actions_flash.addWidget(actions_flash_box)
		# buttons actions
		flash_button = QPushButton("Start Flash")
		re_flash = QPushButton("Reboot to Flash")
		empty_label_actions = QLabel()
		actions_flash_layout.addWidget(flash_button)
		actions_flash_layout.addWidget(re_flash)
		actions_flash_layout.addWidget(empty_label_actions)

		# empty label
		img_empty_laebl = QLabel()
		img_layout.addWidget(img_empty_laebl)

class help_Widget(QWidget):
	def __init__(self):
		super().__init__()
		# main layout
		main_layout = QHBoxLayout()
		self.setLayout(main_layout)

class setting_Widget(QWidget):
	def __init__(self):
		super().__init__()
		# main layout
		main_layout = QHBoxLayout()
		self.setLayout(main_layout)